<link rel="icon" href="image/favicon.png" type="image/x-icon">
<link rel="shortcut icon" href="image/favicon.png" type="image/x-icon">

<link rel="stylesheet" href="css/styles.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/content-styles.css">
